# BORAL – QLD

Site: Capalaba
Location: 11/13-15 Smith St, Capalaba QLD 4157
Phone Number: Mitch: 0401 893 552
Status: Active
Notes: 21 / 01 – Up to date. Batcher – Adam (0401 893 552). 29 / 08 / 24 – New hose reel & stopper installed on Truck Wash. 05 / 08 / 24 – Computer Card Scanning System currently not operational because there is no constant power there at the moment. Spoke to Max Electrician and November he is installing a constant power supply in the plant. Currently just running on bypass. 20 / 06 / 24 – Install done. 04 / 06 / 24 – Installation required and compressor needed!