# BORAL – QLD

Site: Ipswich
Location: 203-219 Briggs Rd, Ipswich QLD 4305
Phone Number: 0401 893 707
Status: Active
Notes: 21 / 01 – Closed until further notice. 04 / 06 – Site Contact Jake from Redbank. Likely closed for a while.