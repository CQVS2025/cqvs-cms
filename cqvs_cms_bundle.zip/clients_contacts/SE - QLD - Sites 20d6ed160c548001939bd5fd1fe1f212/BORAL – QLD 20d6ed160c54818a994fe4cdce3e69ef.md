# BORAL – QLD

Site: Kippa-Ring
Location: 232 Anzac Ave, Redcliffe QLD 4020
Phone Number: Tony: 0401 897 870
Status: Inactive
Notes: Installation 29 / 01