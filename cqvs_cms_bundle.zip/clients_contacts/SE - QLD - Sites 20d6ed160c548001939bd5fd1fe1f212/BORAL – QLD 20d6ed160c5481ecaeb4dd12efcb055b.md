# BORAL – QLD

Site: Caloundra
Location: 11 Industrial Ave, Caloundra West QLD 4551
Status: Active
Notes: 04 / 06 – Up to date: NO COMPUTERS. Need a bucket weight design for Carlson.