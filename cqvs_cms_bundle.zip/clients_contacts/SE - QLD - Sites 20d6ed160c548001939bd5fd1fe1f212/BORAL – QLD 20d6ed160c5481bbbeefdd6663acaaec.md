# BORAL – QLD

Site: Cleveland
Location: 267-275 Industry Ct, Cleveland QLD 4163
Status: Active
Notes: 18 / 02 – New Acid IBC Installed – 850 L Acid Recovered – 50 L Delivered 18 / 02. PLANT OPEN 21 / 01 – CLOSED UNTIL FURTHER NOTICE. CLEVELAND PLANT – (0401 894 702) cleveland.plant@boral.com.au 19 / 07 – Plant Closed until further notice. 06 / 06 – Blair to call Area Manager to understand opening times. Jonny went and was closed. 02 / 06 – Site closed? System offline – Need to contact.