# REDIMIX CONCRETE

Site: WAMBO
Location: Diamondy QLD 4410
Status: Inactive
Notes: 21 / 01 need to follow up David Kennedy Plant Manager – (0461 495 320) DavidKennedy@redimix.com.au 04 / 06 – Next delivery need 2 × new comps as VNC not working on existing computers 10 / 04 – System Service Completed. Coletek 067 – has no VNC but is working. Need another computer for Truck wash.