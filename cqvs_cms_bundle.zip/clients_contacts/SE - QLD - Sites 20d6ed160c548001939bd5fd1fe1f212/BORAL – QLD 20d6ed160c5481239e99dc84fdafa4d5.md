# BORAL – QLD

Site: Southport
Location: 47 Bailey Cres, Southport QLD 4215
Status: Active
Notes: 21 / 01 – Ready for a quote – to speak to Andrew. 02 / 06 Blair to investigate full system installation.