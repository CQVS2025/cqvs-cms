# SUNMIX CONCRETE

Site: Swanbank
Location: 32 Rob Roy Way, Swanbank QLD 4306
Status: Active
Notes: 24 / 02 – The acid dilution system was removed and changed to an acid concentrate system. All systems go. 21 / 01 – Comms with Ted / Jonny. 04 / 06 – Up to date Installation date late MAY