# WAGNERS

Site: Wacol
Location: 20 Airy St, Wacol QLD 4076
Status: Inactive
Notes: Adele Batcher Email: Wacol.Concrete@wagner.com.au Phone: 1300 924 637 29 / 08 / 24 – New SIM Card installed, All Systems Go. 05 / 08 / 24 – Internet connection on modem seems to be dropping in and out, installing new one by the end of the week, which is 09 / 08 / 24. 04 / 06 / 24 – Up to date.